import { invoke } from '@tauri-apps/api/core';
import { listen } from '@tauri-apps/api/event';
import { open } from '@tauri-apps/plugin-dialog';
import { AppSettings, CompressTask, FmtResult } from '../types';

export const tauriApi = {
  getSettings: () => invoke<AppSettings>('get_settings'),
  saveSettings: (settings: AppSettings) => invoke<void>('save_settings', { settings }),
  compressImages: (tasks: CompressTask[]) => invoke<void>('compress_images', { tasks }),
  openFolder: (path: string) => invoke<void>('open_folder', { path }),
  openUrl: (url: string) => invoke<void>('open_url', { url }),
};

// ── Persistent settings (read/write done in Rust, no fs scope issues) ──────

export async function loadPersistedSettings(): Promise<Partial<AppSettings>> {
  try {
    const text = await invoke<string>('load_settings_file');
    if (!text) return {};
    return JSON.parse(text) as Partial<AppSettings>;
  } catch {
    return {};
  }
}

export async function persistSettings(settings: AppSettings): Promise<void> {
  await invoke<void>('save_settings_file', {
    content: JSON.stringify(settings, null, 2),
  });
}

export async function clearPersistedSettings(): Promise<void> {
  await invoke<void>('clear_settings_file');
}

// ── File pickers ────────────────────────────────────────────────────────────

export const pickDirectory = async (): Promise<string | null> => {
  const result = await open({ directory: true, multiple: false });
  return result as string | null;
};

export const pickImages = async (): Promise<string[] | null> => {
  const result = await open({
    multiple: true,
    filters: [{ name: 'Images', extensions: ['png', 'jpg', 'jpeg', 'webp', 'avif'] }],
  });
  if (!result) return null;
  return Array.isArray(result) ? result : [result];
};

// ── Event listeners ─────────────────────────────────────────────────────────

export type FmtResultPayload = {
  task_id: string;
  result: FmtResult;
};

export const listenFmtResults = (
  cb: (payload: FmtResultPayload) => void
) => listen<FmtResultPayload>('fmt-result', (e) => cb(e.payload));

export const listenAllDone = (cb: () => void) =>
  listen('all-done', () => cb());
